const express =require("express");
const route = express.Router();
const controller = require("../controller/addController");
const multer = require("multer");
const path = require("path")
const storage = multer.diskStorage({
    destination : "./src/images",
    filename:(req,file,cb)=>{
        return cb(null, `${file.fieldname}_${Date.now()}${path.extname(file.originalname)}`)
    }
});


const upload =multer({
    storage:storage
})

// 
route.get("/displayuser", controller.displayuser);
route.post("/registrationuser",upload.single('image'), controller.registrationuser);
route.post("/loginuser", controller.loginuser);
route.delete("/deleteuser/:id",controller.deletuser);
route.put("/updateuser/:id",upload.single('image'),controller.updateuser);
route.get("/searchuser/:key",controller.searchuser);


module.exports=route;