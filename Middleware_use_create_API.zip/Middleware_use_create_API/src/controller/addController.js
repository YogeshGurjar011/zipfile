// displaying list of user

const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
// const { response, request } = require("express");


const displayuser = async (req, resp, next) => {
    try {
        var db = req.con;
        let results = await db.query("select * from adduser", function (error, result) {
            if (error) {
                console.log(error)
            }
            else {
                resp.send({
                    status: 1,
                    message: "succefuly ", result
                })
            }
        })
    }
    catch (error) {
        resp.send({
            message: "An error occured"
        })
    }
}
//------------post

const registrationuser = async (req, resp, next) => {
    try {
        var db = req.con;
        var pass = req.body.password;
        var value = bcrypt.hashSync(pass, 10);
        var data = {

            firstname: req.body.firstname,
            lastname: req.body.lastname,
            email: req.body.email,
            password: value,
            image: req.file.filename
        }
        let result = await db.query("INSERT into adduser set ?", [data], function (error, result, fields) {
            if (error) {
                resp.send({
                    message: "An error", error
                })
            }
            else {
                resp.send({
                    message: "Succefully Registration User ", result
                })
            }
        })

    }
    catch (error) {
        resp.send({
            message: "An error occured"
        })
    }
}

// login user with email and password


const loginuser = async (request, response, next) => {
    try {
        db = request.con;
        let email = request.body.email;
        var sql = `select * from registrationuser where email = ?`
        let result =await db.query(sql,[email],function(error,result,fields){
            if(error){
                return response.send(error)
            }
            else if(result.length > 0){
                if(bcrypt.compare(request.body.password,result[0].password)){
                    const token = jwt.sign({loginAdmin : result}, '12345');
                    response.status(201).json({message:'login successfully.', token: token})
                }
                else {
                    response.send("password dose not match");
                }
            }
            else{
                 response.send("email is not correct");
            }
        })
    }
    catch (error) {
        response.send({
            message: "An error occured"
        })
    }
}


// delete user API with use of middleware
const deletuser = async (req, resp, next) => {
    try {
        var db = req.con;
        var id = req.params.id;
        await db.query(`DELETE FROM adduser WHERE id=?`, id, function (error, result, fields) {
            if (error) {
                resp.send({
                    message: "An error", error
                })
            }
            else {
                resp.send({
                    message: "Succefully delete User :", result
                })
            }
        })
    }
    catch (error) {
        resp.send({
            message: "An error occured"
        })
    }
}


// update user API with use of middleware
const updateuser = async (req, resp, next) => {
    try {
        // console.log(req.params.id)
        var db = req.con;
        var id = req.params.id;
        var firstname = req.body.firstname;
        var lastname = req.body.lastname;
        var email = req.body.email;
        var pass = req.body.password;
        var password = bcrypt.hashSync(pass, 10);
        var image = req.file.filename;
        var sql = "UPDATE adduser SET firstname=?, lastname=?,email=?,password=?,image=? where id=?";

        await db.query(sql, [firstname, lastname, email, password, image, id], function (error, result, fields) {
            if (error) {
                resp.send(error)
            }
            else {
                resp.send({ message: "success ", result })
            }
        })
    }
    catch (error) {
        resp.send({
            message: "An error occured"
        })
    }
}



const searchuser = async (req, resp, next) => {
    try {
        db = req.con;
        var firstname = req.params.key;
        var lastname = req.params.key;
        var email = req.params.key;
        var sql = "select * from adduser where firstname LIKE '%"+ firstname+"%' OR lastname LIKE '%"+ lastname + "%' OR email LIKE '%"+ email + "%'";
        let result = await db.query(sql, function (error, result, fields) {
            if (error) {
                console.log(error)
            }
            else {
                resp.send(result);
            }
        })
    }
    catch (error) {
        resp.send({
            message: "An error occured"
        })
    }
}

module.exports = { displayuser, registrationuser, loginuser, deletuser, updateuser, searchuser };