const express = require('express');
const con = require("./dbconnect");
const app = express();
const bodyParser= require("body-parser")
app.use(bodyParser.urlencoded({extended:false}))
app.use(express.json());
const route = require("./src/routes/routes");


app.use(function(req,resp,next){
    req.con = con;
    next();
})


//route

app.use("/adduser",route)

module.exports = app;







//connection check
con.connect(function(error){
    if(error){
        console.log("database not connected",error)
    }
    else{
        console.log("connection succeffuly")
    }
})


//running port
app.listen(5050,(error)=>{
   if(error){
    console.log("port connection",error)
   } 
   else {
    console.log("Server Running");
   }
})