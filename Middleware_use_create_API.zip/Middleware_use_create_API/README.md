# Middleware_use_create_API
this is the use of the middleware to integrated the Mysql database for the api
